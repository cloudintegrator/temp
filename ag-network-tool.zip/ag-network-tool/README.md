# Sample request

```
curl --location --request POST 'https://ag-network-tool-u6h145.4yrozf.bra-s1.cloudhub.io' \
--header 'Content-Type: application/json' \
--data-raw '{
    "cmd": "ping -c 10 www.google.com"
}'
```